package com.google;

import org.w3c.dom.ls.LSOutput;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class VideoPlayer{

  private final VideoLibrary videoLibrary;

  //private final VideoPlaylist videoPlaylist;

  //private Video videoPlaying;

  public List<String> currentlyPlaying = new ArrayList<>();

  boolean videoPaused;

  public VideoPlayer() {
    this.videoLibrary = new VideoLibrary();
  }

  public String[][] allVideos = new String[][] {{"Amazing Cats","(amazing_cats_video_id)", "[#cat #animal]"},
          {"Another Cat Video","(another_cat_video_id)","[#cat #animal]"},
          {"Funny Dogs","(funny_dogs_video_id)","[#dog #animal]"},
          {"Life at Google","(life_at_google_video_id)","[#google #career]"},
          {"Video about nothing","(nothing_video_id)","[]"}};

  public static HashMap<String, String> video = new HashMap<String, String>();
  static {
    video.put("funny_dogs_video_id", "Funny Dogs");
    video.put("amazing_cats_video_id", "Amazing Cats");
    video.put("another_cat_video_id", "Another Cat Video");
    video.put("life_at_google_video_id", "Life at Google");
    video.put("nothing_video_id", "Video about nothing");
  }

  List<String> newPlaylist = new ArrayList<>();

  public void numberOfVideos() {
    System.out.printf("%s videos in the library%n", videoLibrary.getVideos().size());
  }

  public void showAllVideos() {
    List<Video> showallvid = videoLibrary.getVideos();
    ArrayList<String> str = new ArrayList<String>();
    System.out.println("Here's a list of all available videos:");
    for (Video v : showallvid) {
      str.add(v.getVideo());
      Collections.sort(str);
    }
    for (String vid : str) {
      System.out.println(" " + vid);
    }
  }


  public void playVideo(String videoId) {

    if (video.get(videoId) == null){
      System.out.println("Cannot play video: Video does not exist");
    } else {
      if (currentlyPlaying.size() > 0){
        stopVideo();
      }
      System.out.println("Playing video: " + video.get(videoId));
      currentlyPlaying.add(video.get(videoId));
      videoPaused = false;
    }
  }


  public void stopVideo() {
    try {
      System.out.println("Stopping video: " + currentlyPlaying.get(0));
      currentlyPlaying.remove(0);
    } catch (Exception e) {
      System.out.println("Cannot stop video: No video is currently playing");
    }
  }


  public void playRandomVideo() {
    if (currentlyPlaying.size() > 0) {
      stopVideo();
    }
    Random r = new Random();
    Object[] values = video.values().toArray();
    Object randomValue = values[r.nextInt(values.length)];
    System.out.println("Playing video: " + randomValue);
    currentlyPlaying.add((String) randomValue);
  }


  public void pauseVideo() {
    if (currentlyPlaying.size() > 0 && videoPaused == false){
      System.out.println("Pausing video: " + currentlyPlaying.get(0));
      videoPaused = true;
    }
    else if (currentlyPlaying.size() > 0 && videoPaused == true){
      System.out.println("Video already paused: " + currentlyPlaying.get(0));
    }
    else {
      System.out.println("Cannot pause video: No video is currently playing");
    }
  }


  public void continueVideo() {
    if (currentlyPlaying.size() > 0 && videoPaused == true){
      System.out.println("Continuing video: " + currentlyPlaying.get(0));
      videoPaused = false;
    }
    else if (currentlyPlaying.size() > 0 && videoPaused == false){
      System.out.println("Cannot continue video: Video is not paused");
    }
    else if (currentlyPlaying.size() == 0){
      System.out.println("Cannot continue video: No video is currently playing");
    }
  }

  public void showPlaying() {
    if (currentlyPlaying.size() == 0){
      System.out.println("No video is currently playing");
    } else {
      for (int i = 0; i < allVideos.length; i++){
        if (currentlyPlaying.get(0) == allVideos[i][0] && videoPaused == false){
          System.out.println("Currently playing: " + allVideos[i][0] + " " + allVideos[i][1]+ " " + allVideos[i][2]);
        }
        else if (currentlyPlaying.get(0) == allVideos[i][0] && videoPaused == true){
          System.out.println("Currently playing: " + allVideos[i][0] + " " + allVideos[i][1]+ " " + allVideos[i][2] + " - PAUSED");
        }
      }
    }
  }

  Map<String, VideoPlaylist> playListMap = new HashMap<>();
  public void createPlaylist(String playlistName) {
    String lowerCaseName = playlistName.toLowerCase();
    if (playListMap.containsKey(lowerCaseName)) {
      System.out.println("Cannot create playlist: A playlist with the same name already exists");
    } else {
      playListMap.put(lowerCaseName, new VideoPlaylist(playlistName));
      System.out.println("Successfully created new playlist: " + playlistName);
    }
  }


  public void addVideoToPlaylist(String playlistName, String videoId) {
  }

  public void showAllPlaylists() {
    System.out.println("showAllPlaylists needs implementation");
  }

  public void showPlaylist(String playlistName) {
    System.out.println("showPlaylist needs implementation");
  }

  public void removeFromPlaylist(String playlistName, String videoId) {
    System.out.println("removeFromPlaylist needs implementation");
  }

  public void clearPlaylist(String playlistName) {
    System.out.println("clearPlaylist needs implementation");
  }

  public void deletePlaylist(String playlistName) {
    System.out.println("deletePlaylist needs implementation");
  }

  public void searchVideos(String searchTerm) {
    System.out.println("searchVideos needs implementation");
  }

  public void searchVideosWithTag(String videoTag) {
    System.out.println("searchVideosWithTag needs implementation");
  }

  public void flagVideo(String videoId) {
    System.out.println("flagVideo needs implementation");
  }

  public void flagVideo(String videoId, String reason) {
    System.out.println("flagVideo needs implementation");
  }

  public void allowVideo(String videoId) {
    System.out.println("allowVideo needs implementation");
  }
}