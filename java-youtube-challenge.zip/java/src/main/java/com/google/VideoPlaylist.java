package com.google;

import java.util.ArrayList;
import java.util.List;

/** A class used to represent a Playlist */
class VideoPlaylist {
    public final String name;
    public List<Video> videos;

    VideoPlaylist(String name) {
        this.name = name;
        this.videos = new ArrayList<>();
    }
     public boolean getAddVideo (Video video){
         if (videos.contains(video)){
             return false;
         }
         else {
             videos.add(video);
             return true;
         }
    }

}
